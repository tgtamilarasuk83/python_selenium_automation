import time

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
import python_selenium.Helper.helper as helper

driver = webdriver.Chrome()
wait = WebDriverWait(driver, 10)

# ---------------- OPEN WEBSITE ----------------
driver.get("https://automationexercise.com")
driver.maximize_window()

# ---------------- VERIFY LOGO ----------------
logo = wait.until(
    EC.visibility_of_element_located(
        (By.XPATH, "//img[@alt='Website for automation practice']")
    )
)

assert logo.is_displayed(), "Logo is not displayed"
print("SUCCESS: Logo is displayed")

# ---------------- SIGNUP PAGE ----------------
signup = wait.until(
    EC.element_to_be_clickable(
        (By.XPATH, "//a[normalize-space()='Signup / Login']")
    )
)

driver.execute_script("arguments[0].click();", signup)

newsletter = wait.until(
    EC.visibility_of_element_located(
        (By.XPATH, "//h2[normalize-space()='New User Signup!']")
    )
)

assert newsletter.is_displayed(), "Signup section is not displayed"
print("SUCCESS: Signup section is displayed")

# ---------------- SIGNUP DETAILS ----------------
helper.type_text("//input[@placeholder='Name']", "Tamilarasu")
helper.type_text("//input[@data-qa='signup-email']", "tamilsua@gmail.com")
helper.click("//button[normalize-space()='Signup']")

# ---------------- ACCOUNT INFO ----------------
helper.click("//input[@id='id_gender2']")
helper.type_text("//input[@id='password']", "Tamil@2004")

helper.select_dropdown("//select[@id='days']", "20")
helper.select_dropdown("//select[@id='months']", "June")
helper.select_dropdown("//select[@id='years']", "2000")

# ---------------- CHECKBOXES ----------------
helper.click("//input[@id='newsletter']")
helper.click("//input[@id='optin']")

# ---------------- ADDRESS DETAILS ----------------
helper.type_text("//input[@id='first_name']", "Tamil")
helper.type_text("//input[@id='last_name']", "Arasu")
helper.type_text("//input[@id='company']", "ABC Company")
helper.type_text("//input[@id='address1']", "Chennai Main Road")
helper.type_text("//input[@id='address2']", "Near Bus Stand")

helper.select_dropdown("//select[@id='country']", "Canada")

helper.type_text("//input[@id='state']", "Ontario")
helper.type_text("//input[@id='city']", "Toronto")
helper.type_text("//input[@id='zipcode']", "M1B 1A1")
helper.type_text("//input[@id='mobile_number']", "9876543210")

# ---------------- CREATE ACCOUNT ----------------
helper.click("//button[normalize-space()='Create Account']")

# ---------------- WAIT ----------------
time.sleep(5)

driver.quit()